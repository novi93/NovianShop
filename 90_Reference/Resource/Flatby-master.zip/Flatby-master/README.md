Flatby UI Kit
=========

Flatby is a free, flat ui kit for your projects. It uses SCSS type sass for stylesheets, and is (usualy) under development.

- html5
- scss
- Free for any kind of project

You can check it out live on codepen (http://codepen.io/dennisschipper/details/EFwah).

To do (soon):
--

- Add "fat" styles to elements
- Rewrite parts of the css to make more sense

Updates
=======

Added paging
Added CSS for pagination

Thanks @bootstrap ;)
